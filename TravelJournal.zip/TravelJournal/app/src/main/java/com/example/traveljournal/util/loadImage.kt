package com.example.traveljournal.util

//TODO: future
//import android.widget.ImageView
//import com.example.traveljournal.R
//import com.bumptech.glide.request.RequestOptions
//
//fun ImageView.loadImage(uri: String?) {
//    val options = RequestOptions()
//        .placeholder(R.drawable.loader)
//
//}